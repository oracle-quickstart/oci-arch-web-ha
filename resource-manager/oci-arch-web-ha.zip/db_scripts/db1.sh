export LD_LIBRARY_PATH=/usr/lib/oracle/18.3/client64/lib
/usr/lib/oracle/18.3/client64/bin/sqlplus admin/ATP_password@ATP_database_db_name_medium @/home/opc/db1.sql > /home/opc/db1.log
